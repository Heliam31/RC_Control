/* Do we know about the C type sigset_t? */
#undef HAVE_SIGSET_T

