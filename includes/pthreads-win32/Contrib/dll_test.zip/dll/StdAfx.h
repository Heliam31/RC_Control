#ifndef HEADER_PRECOMPILED_DLL_STUFF
# define HEADER_PRECOMPILED_DLL_STUFF

# if _MSC_VER > 1000
#  pragma once
# endif // _MSC_VER > 1000


//System
#include <windows.h>

//STL
#include <iostream>
#include <exception>


#endif //HEADER_PRECOMPILED_DLL_STUFF
//EOF
