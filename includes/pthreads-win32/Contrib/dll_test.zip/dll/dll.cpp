#include "stdafx.h"
#include "dll.h"

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    switch (ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH:
		case DLL_THREAD_ATTACH:
		case DLL_THREAD_DETACH:
		case DLL_PROCESS_DETACH:
			break;
    }
    return TRUE;
}


// This is an example of an exported function.
DLL_API void dll_function()
{
    terminate_function fn = set_terminate(0);
    set_terminate(fn);
    std::cout << "DLL: Terminate handler = 0x" << fn << std::endl;
}
