#include "stdafx.h"
#include "../dll/dll.h"

void my_function()
{
    //std::cout << "APP: My terminate handler" << std::endl;
}


int main()
{
    set_terminate(my_function);

    terminate_function fn = set_terminate(0);
    set_terminate(fn);
    std::cout << "APP: Terminate handler = 0x" << fn << std::endl;

    dll_function();

    return 0;
}


//EOF
