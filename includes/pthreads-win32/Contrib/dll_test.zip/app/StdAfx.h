#ifndef HEADER_APP_PRECOMPILED_STUFF
# define HEADER_APP_PRECOMPILED_STUFF

# if _MSC_VER > 1000
#  pragma once
# endif // _MSC_VER > 1000


# include <iostream>


#endif //HEADER_APP_PRECOMPILED_STUFF
//EOF
